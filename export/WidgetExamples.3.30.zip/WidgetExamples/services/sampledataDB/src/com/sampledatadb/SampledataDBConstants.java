
package com.sampledatadb;



/**
 *  Query names for service "sampledataDB"
 *  09/15/2011 14:48:25
 * 
 */
public class SampledataDBConstants {

    public final static String getInventoryByIdQueryName = "getInventoryById";

}
